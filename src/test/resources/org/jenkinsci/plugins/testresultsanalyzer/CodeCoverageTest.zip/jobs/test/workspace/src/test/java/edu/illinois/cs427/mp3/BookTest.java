package edu.illinois.cs427.mp3;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class BookTest {

    @Test
    //simple, set title to fieldname
    public void testBookConstructor1() {
        Book newBook = new Book("title", "author");

        String expectedTitle = "title";
        String expectedAuthor = "author";

        assertEquals(expectedAuthor, newBook.getAuthor());
        assertEquals(expectedTitle, newBook.getTitle());
    }

    @Test
    //simple, with special characters
    public void testBookConstructor2() {
        Book newBook = new Book("Catcher in the Rye", "J.D. Salinger");

        String expectedTitle = "Catcher in the Rye";
        String expectedAuthor = "J.D. Salinger";

        assertEquals(expectedAuthor, newBook.getAuthor());
        assertEquals(expectedTitle, newBook.getTitle());
    }

    @Test
    //stringRepresentation constructor
    public void testBookConstructor3() {
        //arrange
        String xml = "<book>\n" +
                "  <author>J.D. Salinger</author>\n" +
                "  <title>Catcher in the Rye</title>\n" +
                "</book>";

        String expectedTitle = "Catcher in the Rye";
        String expectedAuthor = "J.D. Salinger";

        //act
        Book newBook = new Book(xml);

        //assert
        assertEquals(expectedAuthor, newBook.getAuthor());
        assertEquals(expectedTitle, newBook.getTitle());
    }

    @Test
    //stringRepresentation constructor, swap author/title
    public void testBookConstructor4() {
        //arrange
        String xml = "<book>\n" +
                "  <title>Catcher in the Rye</title>\n" +
                "  <author>J.D. Salinger</author>\n" +
                "</book>";

        String expectedTitle = "Catcher in the Rye";
        String expectedAuthor = "J.D. Salinger";

        //act
        Book newBook = new Book(xml);

        //assert
        assertEquals(expectedAuthor, newBook.getAuthor());
        assertEquals(expectedTitle, newBook.getTitle());
    }

    @Test
    //simple, null title
    public void testBookConstructor5()
    {
        Book newBook = new Book(null, "J.D. Salinger");

        assertNull(newBook.getTitle());
    }

    @Test
    //simple, null author
    public void testBookConstructor6()
    {
        Book newBook = new Book("Catcher in the Rye", null);

        assertNull(newBook.getAuthor());
    }

    @Test
    //simple, null author and title
    public void testBookConstructor7()
    {
        Book newBook = new Book(null, null);

        assertNull(newBook.getTitle());
        assertNull(newBook.getAuthor());
    }

    @Test
    //simple, empty author and title
    public void testBookConstructor8()
    {
        Book newBook = new Book("", "");

        assertEquals("", newBook.getAuthor());
        assertEquals("", newBook.getTitle());
    }

    @Test
    //stringRepresentation constructor, empty title
    public void testBookConstructor9() {
        String xml = "<book>\n" +
                "  <title></title>\n" +
                "  <author>Orson Scott Card</author>\n" +
                "</book>";

        Book newBook = new Book(xml);

        assertEquals("", newBook.getTitle());
    }

    @Test
    //stringRepresentation constructor, empty author
    public void testBookConstructor10() {
        String xml = "<book>\n" +
                "  <title>Ender&apos;s Game</title>\n" +
                "  <author></author>\n" +
                "</book>";

        Book newBook = new Book(xml);

        assertEquals("", newBook.getAuthor());
    }

    @Test
    //stringRepresentation constructor, empty title & author
    public void testBookConstructor11() {
        String xml = "<book>\n" +
                "  <title></title>\n" +
                "  <author></author>\n" +
                "</book>";

        Book newBook = new Book(xml);

        assertEquals("", newBook.getAuthor());
        assertEquals("", newBook.getTitle());
    }

    @Test(expected = Exception.class)
    //stringRepresentation constructor, invalid string
    public void testBookConstructor12() {
        String xml = "<book<>>\n" +
                "  <x>Head First Java, 2nd Edition</y>\n" +
                "  <z>Kathy Sierra, Bert Bates</h>\n" +
                "</book>";

        new Book(xml);
    }

    @Test
    //stringRepresentation constructor, special character
    public void testGetStringRepresentation1() {
        Book newBook = new Book("Ender's Game", "Orson Scott Card");

        String expectedRepresentation = "<book>\n" +
                "  <title>Ender&apos;s Game</title>\n" +
                "  <author>Orson Scott Card</author>\n" +
                "</book>";

        assertEquals(expectedRepresentation, newBook.getStringRepresentation());
    }

    @Test
    //Simple example (CS -> OS -> Linux)
    public void testGetContainingCollections1() {
        //arrange
        Collection computerScienceCollection = new Collection("Computer Science");
        Collection operatingSystemsCollection = new Collection("Operating Systems");
        Book linuxKernelBook = new Book("The Linux Kernel", "Remy Card");

        operatingSystemsCollection.addElement(linuxKernelBook);
        computerScienceCollection.addElement(operatingSystemsCollection);

        //act
        List<Collection> expectedCollections = new ArrayList<>();
        expectedCollections.add(operatingSystemsCollection);
        expectedCollections.add(computerScienceCollection);

        List<Collection> actualCollections = linuxKernelBook.getContainingCollections();

        //assert
        assertArrayEquals(expectedCollections.toArray(), actualCollections.toArray());
    }

    @Test
    //Different instance of collections with same name
    public void testGetContainingCollections2()
    {
        Collection computerScienceCollection1 = new Collection("Computer Science");
        Collection computerScienceCollection2 = new Collection("Computer Science");
        Book linuxKernelBook = new Book("The Linux Kernel", "Remy Card");

        computerScienceCollection1.addElement(computerScienceCollection2);
        computerScienceCollection2.addElement(linuxKernelBook);

        List<Collection> expectedCollections = new ArrayList<>();
        expectedCollections.add(computerScienceCollection2);
        expectedCollections.add(computerScienceCollection1);

        //act
        List<Collection> containingCollections = linuxKernelBook.getContainingCollections();

        assertEquals(expectedCollections, containingCollections);
    }
}
