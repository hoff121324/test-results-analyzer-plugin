package edu.illinois.cs427.mp3;

import com.thoughtworks.xstream.XStream;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a collection of books or (sub)collections.
 */
public final class Collection extends Element {
    List<Element> elements;
    private String name;

    /**
     * Creates a new collection with the given name.
     *
     * @param name the name of the collection
     */
    public Collection(String name) {
        elements = new ArrayList<Element>();
        this.name = name;
    }

    /**
     * Restores a collection from its given string representation.
     *
     * @param stringRepresentation the string representation
     */
    public static Collection restoreCollection(String stringRepresentation) {
        XStream xStream = new XStream();
        xStream.alias("book", Book.class);
        xStream.alias("collection", Collection.class);

        Collection deserializedCollection = (Collection) xStream.fromXML(stringRepresentation);

        return deserializedCollection;
    }

    /**
     * Returns the string representation of a collection.
     * The string representation should have the name of this collection,
     * and all elements (books/subcollections) contained in this collection.
     *
     * @return string representation of this collection
     */
    public String getStringRepresentation() {
        XStream xStream = new XStream();
        xStream.alias("book", Book.class);
        xStream.alias("collection", Collection.class);

        String collectionRepresentation = xStream.toXML(this);

        return collectionRepresentation;
    }

    /**
     * Returns the name of the collection.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Adds an element to the collection.
     * If parentCollection of given element is not null,
     * do not actually add, but just return false.
     * (explanation: if given element is already a part of
     * another collection, you should have deleted the element
     * from that collection before adding to another collection)
     *
     * @param element the element to add
     * @return true on success, false on fail
     */
    public boolean addElement(Element element) {
        if(element == this)
        {
            throw new IllegalStateException("You can not add a collection to itself");
        }

        if (element.getParentCollection() == null) {
            elements.add(element);
            element.setParentCollection(this);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Deletes an element from the collection.
     * Returns false if the collection does not have
     * this element.
     * Hint: Do not forget to clear parentCollection
     * of given element
     *
     * @param element the element to remove
     * @return true on success, false on fail
     */
    public boolean deleteElement(Element element) {
        if (containsElement(element)) {
            elements.remove(element);
            element.setParentCollection(null);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns the list of elements.
     *
     * @return the list of elements
     */
    public List<Element> getElements() {
        return elements;
    }

    /**
     * @param element
     * @return if the current collection contains the element
     */
    private boolean containsElement(Element element) {
        return elements.contains(element);
    }
}
